#include <stdio.h>
#include <stdlib.h>

#include "mini_d2d1.h"


//IUnknown
HRESULT WINAPI q_ID2D1DeviceContext_QueryInterface(q_ID2D1DeviceContext *This, REFIID riid, void **ppvObject)
{
    LOGNOP;
}
ULONG WINAPI q_ID2D1DeviceContext_AddRef(q_ID2D1DeviceContext *This)
{
    This->refcount++;
    return This->refcount;
}
ULONG WINAPI q_ID2D1DeviceContext_Release(q_ID2D1DeviceContext *This)
{
    ULONG ret = --This->refcount;
    if (ret == 0)
    {
        debug_printf("freeing ID2D1DeviceContext\n");
        if (This->currentTarget) { This->currentTarget->lpVtbl->Release(This->currentTarget); }
        free(This);
    }
    return ret;
}

//ID2D1Resource
void WINAPI q_ID2D1DeviceContext_GetFactory(q_ID2D1DeviceContext *This, ID2D1Factory **factory)
{
    LOGNOP_;
}

//ID2D1RenderTarget
HRESULT WINAPI q_ID2D1DeviceContext__CreateBitmap(q_ID2D1DeviceContext *This, D2D1_SIZE_U size, const void *srcData, UINT32 pitch, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext__CreateBitmapFromWicBitmap(q_ID2D1DeviceContext *This, IWICBitmapSource *wicBitmapSource, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateSharedBitmap(q_ID2D1DeviceContext *This, REFIID riid, void *data, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext__CreateBitmapBrush(q_ID2D1DeviceContext *This, ID2D1Bitmap *bitmap, const D2D1_BITMAP_BRUSH_PROPERTIES *bitmapBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1BitmapBrush **bitmapBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateSolidColorBrush(q_ID2D1DeviceContext *This, const D2D1_COLOR_F *color, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1SolidColorBrush **solidColorBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext__CreateGradientStopCollection(q_ID2D1DeviceContext *This, const D2D1_GRADIENT_STOP *gradientStops, UINT gradientStopsCount, D2D1_GAMMA colorInterpolationGamma, D2D1_EXTEND_MODE extendMode, ID2D1GradientStopCollection **gradientStopCollection)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateLinearGradientBrush(q_ID2D1DeviceContext *This, const D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES *linearGradientBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1GradientStopCollection *gradientStopCollection, ID2D1LinearGradientBrush **linearGradientBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateRadialGradientBrush(q_ID2D1DeviceContext *This, const D2D1_RADIAL_GRADIENT_BRUSH_PROPERTIES *radialGradientBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1GradientStopCollection *gradientStopCollection, ID2D1RadialGradientBrush **radialGradientBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateCompatibleRenderTarget(q_ID2D1DeviceContext *This, const D2D1_SIZE_F *desiredSize, const D2D1_SIZE_U *desiredPixelSize, const D2D1_PIXEL_FORMAT *desiredFormat, D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS options, ID2D1BitmapRenderTarget **bitmapRenderTarget)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateLayer(q_ID2D1DeviceContext *This, const D2D1_SIZE_F *size, ID2D1Layer **layer)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateMesh(q_ID2D1DeviceContext *This, ID2D1Mesh **mesh)
{
    LOGNOP;
}
void WINAPI q_ID2D1DeviceContext_DrawLine(q_ID2D1DeviceContext *This, D2D1_POINT_2F point0, D2D1_POINT_2F point1, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawRectangle(q_ID2D1DeviceContext *This, const D2D1_RECT_F *rect, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_FillRectangle(q_ID2D1DeviceContext *This, const D2D1_RECT_F *rect, ID2D1Brush *brush)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawRoundedRectangle(q_ID2D1DeviceContext *This, const D2D1_ROUNDED_RECT *roundedRect, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_FillRoundedRectangle(q_ID2D1DeviceContext *This, const D2D1_ROUNDED_RECT *roundedRect, ID2D1Brush *brush)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawEllipse(q_ID2D1DeviceContext *This, const D2D1_ELLIPSE *ellipse, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_FillEllipse(q_ID2D1DeviceContext *This, const D2D1_ELLIPSE *ellipse, ID2D1Brush *brush)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawGeometry(q_ID2D1DeviceContext *This, ID2D1Geometry *geometry, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_FillGeometry(q_ID2D1DeviceContext *This, ID2D1Geometry *geometry, ID2D1Brush *brush, ID2D1Brush *opacityBrush)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_FillMesh(q_ID2D1DeviceContext *This, ID2D1Mesh *mesh, ID2D1Brush *brush)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext__FillOpacityMask(q_ID2D1DeviceContext *This, ID2D1Bitmap *opacityMask, ID2D1Brush *brush, D2D1_OPACITY_MASK_CONTENT content, const D2D1_RECT_F *destinationRectangle, const D2D1_RECT_F *sourceRectangle)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext__DrawBitmap(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *bitmap, const D2D1_RECT_F *destinationRectangle, FLOAT opacity, D2D1_BITMAP_INTERPOLATION_MODE interpolationMode, const D2D1_RECT_F *sourceRectangle)
{
    int filter = (interpolationMode == D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR) ? 0 : 1;
    int blend = (This->primitiveBlend == D2D1_PRIMITIVE_BLEND_COPY) ? 0 : 1;
    debug_printf("DrawBitmap-v0\n");
    DrawRectBitmap(This->currentTarget, bitmap->texture, destinationRectangle, sourceRectangle, filter, blend);
}
void WINAPI q_ID2D1DeviceContext_DrawText(q_ID2D1DeviceContext *This, const WCHAR *string, UINT stringLength, IDWriteTextFormat *textFormat, const D2D1_RECT_F *layoutRect, ID2D1Brush *defaultForegroundBrush, D2D1_DRAW_TEXT_OPTIONS options, DWRITE_MEASURING_MODE measuringMode)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawTextLayout(q_ID2D1DeviceContext *This, D2D1_POINT_2F origin, IDWriteTextLayout *textLayout, ID2D1Brush *defaultForegroundBrush, D2D1_DRAW_TEXT_OPTIONS options)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext__DrawGlyphRun(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, const DWRITE_GLYPH_RUN *glyphRun, ID2D1Brush *foregroundBrush, DWRITE_MEASURING_MODE measuringMode)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetTransform(q_ID2D1DeviceContext *This, const D2D1_MATRIX_3X2_F *transform)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_GetTransform(q_ID2D1DeviceContext *This, D2D1_MATRIX_3X2_F *transform)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetAntialiasMode(q_ID2D1DeviceContext *This, D2D1_ANTIALIAS_MODE antialiasMode)
{
    LOGNOP_;
}
D2D1_ANTIALIAS_MODE WINAPI q_ID2D1DeviceContext_GetAntialiasMode(q_ID2D1DeviceContext *This)
{
    return D2D1_ANTIALIAS_MODE_FORCE_DWORD;
}
void WINAPI q_ID2D1DeviceContext_SetTextAntialiasMode(q_ID2D1DeviceContext *This, D2D1_TEXT_ANTIALIAS_MODE textAntialiasMode)
{
    LOGNOP_;
}
D2D1_TEXT_ANTIALIAS_MODE WINAPI q_ID2D1DeviceContext_GetTextAntialiasMode(q_ID2D1DeviceContext *This)
{
    return D2D1_TEXT_ANTIALIAS_MODE_FORCE_DWORD;
}
void WINAPI q_ID2D1DeviceContext_SetTextRenderingParams(q_ID2D1DeviceContext *This, IDWriteRenderingParams *textRenderingParams)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_GetTextRenderingParams(q_ID2D1DeviceContext *This, IDWriteRenderingParams **textRenderingParams)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetTags(q_ID2D1DeviceContext *This, D2D1_TAG tag1, D2D1_TAG tag2)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_GetTags(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext__PushLayer(q_ID2D1DeviceContext *This, const D2D1_LAYER_PARAMETERS *layerParameters, ID2D1Layer *layer)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_PopLayer(q_ID2D1DeviceContext *This)
{
    LOGNOP_;
}
HRESULT WINAPI q_ID2D1DeviceContext_Flush(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2)
{
    LOGNOP;
}
void WINAPI q_ID2D1DeviceContext_SaveDrawingState(q_ID2D1DeviceContext *This, ID2D1DrawingStateBlock *drawingStateBlock)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_RestoreDrawingState(q_ID2D1DeviceContext *This, ID2D1DrawingStateBlock *drawingStateBlock)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_PushAxisAlignedClip(q_ID2D1DeviceContext *This, const D2D1_RECT_F *clipRect, D2D1_ANTIALIAS_MODE antialiasMode)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_PopAxisAlignedClip(q_ID2D1DeviceContext *This)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_Clear(q_ID2D1DeviceContext *This, const D2D1_COLOR_F *clearColor)
{
    debug_printf("ID2D1DeviceContext_Clear\n");
    if (This->currentTarget == NULL) { debug_printf("... null target\n"); return; }

    ClearBitmap(This->currentTarget, (float*)clearColor);
}
void WINAPI q_ID2D1DeviceContext_BeginDraw(q_ID2D1DeviceContext *This)
{
    //LOGNOP_;
    debug_printf(">>>>>>\n");
}
HRESULT WINAPI q_ID2D1DeviceContext_EndDraw(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2)
{
    //LOGNOP;
    debug_printf("<<<<<<\n");
    return S_OK;
}
D2D1_PIXEL_FORMAT WINAPI q_ID2D1DeviceContext_GetPixelFormat(q_ID2D1DeviceContext *This)
{
    D2D1_PIXEL_FORMAT ret = {};
    LOGNOP_;
    return ret;
}
void WINAPI q_ID2D1DeviceContext_SetDpi(q_ID2D1DeviceContext *This, FLOAT dpiX, FLOAT dpiY)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_GetDpi(q_ID2D1DeviceContext *This, FLOAT *dpiX, FLOAT *dpiY)
{
    LOGNOP_;
}
D2D1_SIZE_F WINAPI q_ID2D1DeviceContext_GetSize(q_ID2D1DeviceContext *This)
{
    D2D1_SIZE_F ret = {};
    LOGNOP_;
    return ret;
}
D2D1_SIZE_U WINAPI q_ID2D1DeviceContext_GetPixelSize(q_ID2D1DeviceContext *This)
{
    D2D1_SIZE_U ret = {};
    LOGNOP_;
    return ret;
}
UINT32 WINAPI q_ID2D1DeviceContext_GetMaximumBitmapSize(q_ID2D1DeviceContext *This)
{
    LOGNOP_;
    return 0;
}
BOOL WINAPI q_ID2D1DeviceContext_IsSupported(q_ID2D1DeviceContext *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties)
{
    LOGNOP_;
    return 0;
}

//ID2D1DeviceContext
HRESULT WINAPI q_ID2D1DeviceContext_CreateBitmap(q_ID2D1DeviceContext *This, D2D1_SIZE_U size, CONST void *sourceData, UINT32 pitch, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, ID2D1Bitmap1 **bitmap)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateBitmapFromWicBitmap(q_ID2D1DeviceContext *This, IWICBitmapSource *wicBitmapSource, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, ID2D1Bitmap1 **bitmap)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateColorContext(q_ID2D1DeviceContext *This, D2D1_COLOR_SPACE space, CONST BYTE *profile, UINT32 profileSize, ID2D1ColorContext **colorContext)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateColorContextFromFilename(q_ID2D1DeviceContext *This, PCWSTR filename, ID2D1ColorContext **colorContext)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateColorContextFromWicColorContext(q_ID2D1DeviceContext *This, IWICColorContext *wicColorContext, ID2D1ColorContext **colorContext)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateBitmapFromDxgiSurface(q_ID2D1DeviceContext *This, IDXGISurface *surface, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, q_ID2D1Bitmap1 **bitmap)
{
    q_ID2D1Bitmap1 *bmp;

    debug_printf("CreateBitmapFromDxgiSurface\n");
    if (surface == NULL || bitmap == NULL) { return E_INVALIDARG; }

    bmp = (q_ID2D1Bitmap1*)malloc(sizeof(q_ID2D1Bitmap1));
    bmp->vtbl = &_ID2D1Bitmap1_vtbl;
    bmp->refcount = 1;
    bmp->parent = This;
    bmp->texture = NULL; //just in case
    GetDxgiSurfaceToTexture(surface, &bmp->texture);

    *bitmap = bmp;
    return S_OK;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateEffect(q_ID2D1DeviceContext *This, REFCLSID effectId, ID2D1Effect **effect)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateGradientStopCollection(q_ID2D1DeviceContext *This, CONST D2D1_GRADIENT_STOP *straightAlphaGradientStops, UINT32 straightAlphaGradientStopsCount, D2D1_COLOR_SPACE preInterpolationSpace, D2D1_COLOR_SPACE postInterpolationSpace, D2D1_BUFFER_PRECISION bufferPrecision, D2D1_EXTEND_MODE extendMode, D2D1_COLOR_INTERPOLATION_MODE colorInterpolationMode, ID2D1GradientStopCollection1 **gradientStopCollection1)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateImageBrush(q_ID2D1DeviceContext *This, struct ID2D1Image *image, CONST D2D1_IMAGE_BRUSH_PROPERTIES *imageBrushProperties, CONST D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1ImageBrush **imageBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateBitmapBrush(q_ID2D1DeviceContext *This, ID2D1Bitmap *bitmap, CONST D2D1_BITMAP_BRUSH_PROPERTIES1 *bitmapBrushProperties, CONST D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1BitmapBrush1 **bitmapBrush)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_CreateCommandList(q_ID2D1DeviceContext *This, ID2D1CommandList **commandList)
{
    LOGNOP;
}
BOOL WINAPI q_ID2D1DeviceContext_IsDxgiFormatSupported(q_ID2D1DeviceContext *This, DXGI_FORMAT format)
{
    LOGNOP;
}
BOOL WINAPI q_ID2D1DeviceContext_IsBufferPrecisionSupported(q_ID2D1DeviceContext *This, D2D1_BUFFER_PRECISION bufferPrecision)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetImageLocalBounds(q_ID2D1DeviceContext *This, struct ID2D1Image *image, D2D1_RECT_F *localBounds)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetImageWorldBounds(q_ID2D1DeviceContext *This, struct ID2D1Image *image, D2D1_RECT_F *worldBounds)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetGlyphRunWorldBounds(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, CONST DWRITE_GLYPH_RUN *glyphRun, DWRITE_MEASURING_MODE measuringMode, D2D1_RECT_F *bounds)
{
    LOGNOP;
}
void WINAPI q_ID2D1DeviceContext_GetDevice(q_ID2D1DeviceContext *This, ID2D1Device **device)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetTarget(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *image)
{
    debug_printf("SetTarget %p\n", image);

    //if (This->currentTarget) { This->currentTarget->Release(); }

    if (image == NULL) { This->currentTarget = NULL; }
    else
    {
        if (image->vtbl != &_ID2D1Bitmap1_vtbl) { debug_printf("ID2D1DeviceContext_SetTarget wtf wrong vtbl\n"); return; }
        This->currentTarget = image->texture;
    }
}
void WINAPI q_ID2D1DeviceContext_GetTarget(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 **image)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetRenderingControls(q_ID2D1DeviceContext *This, CONST D2D1_RENDERING_CONTROLS *renderingControls)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_GetRenderingControls(q_ID2D1DeviceContext *This, D2D1_RENDERING_CONTROLS *renderingControls)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_SetPrimitiveBlend(q_ID2D1DeviceContext *This, D2D1_PRIMITIVE_BLEND primitiveBlend)
{
    int blend = (primitiveBlend == D2D1_PRIMITIVE_BLEND_COPY) ? 0 : 1;
    debug_printf("SetPrimitiveBlend [%s]\n", blend ? "on" : "copy");
    This->primitiveBlend = primitiveBlend;
}
D2D1_PRIMITIVE_BLEND WINAPI q_ID2D1DeviceContext_GetPrimitiveBlend(q_ID2D1DeviceContext *This)
{
    LOGNOP_;
    return D2D1_PRIMITIVE_BLEND_FORCE_DWORD;
}
void WINAPI q_ID2D1DeviceContext_SetUnitMode(q_ID2D1DeviceContext *This, D2D1_UNIT_MODE unitMode)
{
    LOGNOP_;
}
D2D1_UNIT_MODE WINAPI q_ID2D1DeviceContext_GetUnitMode(q_ID2D1DeviceContext *This)
{
    LOGNOP_;
    return D2D1_UNIT_MODE_FORCE_DWORD;
}
void WINAPI q_ID2D1DeviceContext_DrawGlyphRun(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, CONST DWRITE_GLYPH_RUN *glyphRun, CONST DWRITE_GLYPH_RUN_DESCRIPTION *glyphRunDescription, ID2D1Brush *foregroundBrush, DWRITE_MEASURING_MODE measuringMode)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawImage(q_ID2D1DeviceContext *This, struct ID2D1Image *image, CONST D2D1_POINT_2F *targetOffset, CONST D2D1_RECT_F *imageRectangle, D2D1_INTERPOLATION_MODE interpolationMode, D2D1_COMPOSITE_MODE compositeMode)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawGdiMetafile(q_ID2D1DeviceContext *This, ID2D1GdiMetafile *gdiMetafile, CONST D2D1_POINT_2F *targetOffset)
{
    LOGNOP_;
}
void WINAPI q_ID2D1DeviceContext_DrawBitmap(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *bitmap, CONST D2D1_RECT_F *destinationRectangle, FLOAT opacity, D2D1_INTERPOLATION_MODE interpolationMode, CONST D2D1_RECT_F *sourceRectangle, CONST D2D1_MATRIX_4X4_F *perspectiveTransform)
{
#if 1
    LOGNOP_;
#else
    int filter = (interpolationMode == D2D1_INTERPOLATION_MODE_NEAREST_NEIGHBOR) ? 0 : 1;
    debug_printf("DrawBitmap-v1");
    DrawRectBitmap(This->currentTarget, bitmap->texture, destinationRectangle, sourceRectangle, filter);
#endif
}
void WINAPI q_ID2D1DeviceContext_PushLayer(q_ID2D1DeviceContext *This, CONST D2D1_LAYER_PARAMETERS1 *layerParameters, ID2D1Layer *layer)
{
    LOGNOP_;
}
HRESULT WINAPI q_ID2D1DeviceContext_InvalidateEffectInputRectangle(q_ID2D1DeviceContext *This, ID2D1Effect *effect, UINT32 input, CONST D2D1_RECT_F *inputRectangle)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetEffectInvalidRectangleCount(q_ID2D1DeviceContext *This, ID2D1Effect *effect, UINT32 *rectangleCount)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetEffectInvalidRectangles(q_ID2D1DeviceContext *This, ID2D1Effect *effect, D2D1_RECT_F *rectangles, UINT32 rectanglesCount)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1DeviceContext_GetEffectRequiredInputRectangles(q_ID2D1DeviceContext *This, ID2D1Effect *renderEffect, CONST D2D1_RECT_F *renderImageRectangle, CONST D2D1_EFFECT_INPUT_DESCRIPTION *inputDescriptions, D2D1_RECT_F *requiredInputRects, UINT32 inputCount)
{
    LOGNOP;
}
void WINAPI q_ID2D1DeviceContext_FillOpacityMask(q_ID2D1DeviceContext *This, ID2D1Bitmap *opacityMask, ID2D1Brush *brush, CONST D2D1_RECT_F *destinationRectangle, CONST D2D1_RECT_F *sourceRectangle)
{
    LOGNOP_;
}





const q_ID2D1DeviceContext_vtbl _ID2D1DeviceContext_vtbl =
{
    //IUnknown
    &q_ID2D1DeviceContext_QueryInterface,
    &q_ID2D1DeviceContext_AddRef,
    &q_ID2D1DeviceContext_Release,

    //ID2D1Resource
    &q_ID2D1DeviceContext_GetFactory,

    //ID2D1RenderTarget
    &q_ID2D1DeviceContext__CreateBitmap,
    &q_ID2D1DeviceContext__CreateBitmapFromWicBitmap,
    &q_ID2D1DeviceContext_CreateSharedBitmap,
    &q_ID2D1DeviceContext__CreateBitmapBrush,
    &q_ID2D1DeviceContext_CreateSolidColorBrush,
    &q_ID2D1DeviceContext__CreateGradientStopCollection,
    &q_ID2D1DeviceContext_CreateLinearGradientBrush,
    &q_ID2D1DeviceContext_CreateRadialGradientBrush,
    &q_ID2D1DeviceContext_CreateCompatibleRenderTarget,
    &q_ID2D1DeviceContext_CreateLayer,
    &q_ID2D1DeviceContext_CreateMesh,
    &q_ID2D1DeviceContext_DrawLine,
    &q_ID2D1DeviceContext_DrawRectangle,
    &q_ID2D1DeviceContext_FillRectangle,
    &q_ID2D1DeviceContext_DrawRoundedRectangle,
    &q_ID2D1DeviceContext_FillRoundedRectangle,
    &q_ID2D1DeviceContext_DrawEllipse,
    &q_ID2D1DeviceContext_FillEllipse,
    &q_ID2D1DeviceContext_DrawGeometry,
    &q_ID2D1DeviceContext_FillGeometry,
    &q_ID2D1DeviceContext_FillMesh,
    &q_ID2D1DeviceContext__FillOpacityMask,
    &q_ID2D1DeviceContext__DrawBitmap,
    &q_ID2D1DeviceContext_DrawText,
    &q_ID2D1DeviceContext_DrawTextLayout,
    &q_ID2D1DeviceContext__DrawGlyphRun,
    &q_ID2D1DeviceContext_SetTransform,
    &q_ID2D1DeviceContext_GetTransform,
    &q_ID2D1DeviceContext_SetAntialiasMode,
    &q_ID2D1DeviceContext_GetAntialiasMode,
    &q_ID2D1DeviceContext_SetTextAntialiasMode,
    &q_ID2D1DeviceContext_GetTextAntialiasMode,
    &q_ID2D1DeviceContext_SetTextRenderingParams,
    &q_ID2D1DeviceContext_GetTextRenderingParams,
    &q_ID2D1DeviceContext_SetTags,
    &q_ID2D1DeviceContext_GetTags,
    &q_ID2D1DeviceContext__PushLayer,
    &q_ID2D1DeviceContext_PopLayer,
    &q_ID2D1DeviceContext_Flush,
    &q_ID2D1DeviceContext_SaveDrawingState,
    &q_ID2D1DeviceContext_RestoreDrawingState,
    &q_ID2D1DeviceContext_PushAxisAlignedClip,
    &q_ID2D1DeviceContext_PopAxisAlignedClip,
    &q_ID2D1DeviceContext_Clear,
    &q_ID2D1DeviceContext_BeginDraw,
    &q_ID2D1DeviceContext_EndDraw,
    &q_ID2D1DeviceContext_GetPixelFormat,
    &q_ID2D1DeviceContext_SetDpi,
    &q_ID2D1DeviceContext_GetDpi,
    &q_ID2D1DeviceContext_GetSize,
    &q_ID2D1DeviceContext_GetPixelSize,
    &q_ID2D1DeviceContext_GetMaximumBitmapSize,
    &q_ID2D1DeviceContext_IsSupported,

    //ID2D1DeviceContext
    &q_ID2D1DeviceContext_CreateBitmap,
    &q_ID2D1DeviceContext_CreateBitmapFromWicBitmap,
    &q_ID2D1DeviceContext_CreateColorContext,
    &q_ID2D1DeviceContext_CreateColorContextFromFilename,
    &q_ID2D1DeviceContext_CreateColorContextFromWicColorContext,
    &q_ID2D1DeviceContext_CreateBitmapFromDxgiSurface,
    &q_ID2D1DeviceContext_CreateEffect,
    &q_ID2D1DeviceContext_CreateGradientStopCollection,
    &q_ID2D1DeviceContext_CreateImageBrush,
    &q_ID2D1DeviceContext_CreateBitmapBrush,
    &q_ID2D1DeviceContext_CreateCommandList,
    &q_ID2D1DeviceContext_IsDxgiFormatSupported,
    &q_ID2D1DeviceContext_IsBufferPrecisionSupported,
    &q_ID2D1DeviceContext_GetImageLocalBounds,
    &q_ID2D1DeviceContext_GetImageWorldBounds,
    &q_ID2D1DeviceContext_GetGlyphRunWorldBounds,
    &q_ID2D1DeviceContext_GetDevice,
    &q_ID2D1DeviceContext_SetTarget,
    &q_ID2D1DeviceContext_GetTarget,
    &q_ID2D1DeviceContext_SetRenderingControls,
    &q_ID2D1DeviceContext_GetRenderingControls,
    &q_ID2D1DeviceContext_SetPrimitiveBlend,
    &q_ID2D1DeviceContext_GetPrimitiveBlend,
    &q_ID2D1DeviceContext_SetUnitMode,
    &q_ID2D1DeviceContext_GetUnitMode,
    &q_ID2D1DeviceContext_DrawGlyphRun,
    &q_ID2D1DeviceContext_DrawImage,
    &q_ID2D1DeviceContext_DrawGdiMetafile,
    &q_ID2D1DeviceContext_DrawBitmap,
    &q_ID2D1DeviceContext_PushLayer,
    &q_ID2D1DeviceContext_InvalidateEffectInputRectangle,
    &q_ID2D1DeviceContext_GetEffectInvalidRectangleCount,
    &q_ID2D1DeviceContext_GetEffectInvalidRectangles,
    &q_ID2D1DeviceContext_GetEffectRequiredInputRectangles,
    &q_ID2D1DeviceContext_FillOpacityMask
};
