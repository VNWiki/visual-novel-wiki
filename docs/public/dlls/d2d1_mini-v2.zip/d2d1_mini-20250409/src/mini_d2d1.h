
//#define INITGUID
#include <d3d11.h>
#include <d2d1.h>
#include <d2d1_1.h>

#ifdef __cplusplus
extern "C" {
#endif


//debug helpers
#ifndef DLLQUIET
    #define debug_printf printf
    #define LOGNOP  return _debug_LOGNOP (__func__)
    #define LOGNOP_ _debug_LOGNOP_(__func__)
#else
    static __attribute__((unused)) void debug_printf(const char *s, ...){}
    #define LOGNOP  return E_NOTIMPL
    #define LOGNOP_
#endif

HRESULT __fastcall _debug_LOGNOP(const char *s);
void __fastcall _debug_LOGNOP_(const char *s);



//exports
HRESULT WINAPI q_D2D1CreateFactory(D2D1_FACTORY_TYPE factoryType, REFIID riid, const D2D1_FACTORY_OPTIONS *pFactoryOptions, void **ppIFactory);



//forward declarations for class structs and vtables
#define FWD(x)  struct q_##x;        typedef struct q_##x        q_##x; \
                struct q_##x##_vtbl; typedef struct q_##x##_vtbl q_##x##_vtbl; extern const q_##x##_vtbl _##x##_vtbl
FWD(ID2D1Factory1);
FWD(ID2D1Device);
FWD(ID2D1DeviceContext);
FWD(ID2D1Bitmap1);
#undef FWD


/// ID2D1Factory1
struct q_ID2D1Factory1
{
    const q_ID2D1Factory1_vtbl *vtbl;
    ULONG refcount;
};

struct q_ID2D1Factory1_vtbl
{
    //IUnknown
    HRESULT WINAPI (*QueryInterface)(q_ID2D1Factory1 *This, REFIID riid, void **ppvObject);
    ULONG WINAPI (*AddRef)(q_ID2D1Factory1 *This);
    ULONG WINAPI (*Release)(q_ID2D1Factory1 *This);

    //ID2D1Factory
    HRESULT WINAPI (*ReloadSystemMetrics)(q_ID2D1Factory1 *This);
    void WINAPI (*GetDesktopDpi)(q_ID2D1Factory1 *This, FLOAT *dpiX, FLOAT *dpiY);
    HRESULT WINAPI (*CreateRectangleGeometry)(q_ID2D1Factory1 *This, const D2D1_RECT_F *rectangle, ID2D1RectangleGeometry **rectangleGeometry);
    HRESULT WINAPI (*CreateRoundedRectangleGeometry)(q_ID2D1Factory1 *This, const D2D1_ROUNDED_RECT *roundedRectangle, ID2D1RoundedRectangleGeometry **roundedRectangleGeometry);
    HRESULT WINAPI (*CreateEllipseGeometry)(q_ID2D1Factory1 *This, const D2D1_ELLIPSE *ellipse, ID2D1EllipseGeometry **ellipseGeometry);
    HRESULT WINAPI (*CreateGeometryGroup)(q_ID2D1Factory1 *This, D2D1_FILL_MODE fillMode, ID2D1Geometry **geometries, UINT geometriesCount, ID2D1GeometryGroup **geometryGroup);
    HRESULT WINAPI (*CreateTransformedGeometry)(q_ID2D1Factory1 *This, ID2D1Geometry *sourceGeometry, const D2D1_MATRIX_3X2_F *transform, ID2D1TransformedGeometry **transformedGeometry);
    HRESULT WINAPI (*_CreatePathGeometry)(q_ID2D1Factory1 *This, ID2D1PathGeometry **pathGeometry);
    HRESULT WINAPI (*_CreateStrokeStyle)(q_ID2D1Factory1 *This, const D2D1_STROKE_STYLE_PROPERTIES *strokeStyleProperties, const FLOAT *dashes, UINT dashesCount, ID2D1StrokeStyle **strokeStyle);
    HRESULT WINAPI (*_CreateDrawingStateBlock)(q_ID2D1Factory1 *This, const D2D1_DRAWING_STATE_DESCRIPTION *drawingStateDescription, IDWriteRenderingParams *textRenderingParams, ID2D1DrawingStateBlock **drawingStateBlock);
    HRESULT WINAPI (*CreateWicBitmapRenderTarget)(q_ID2D1Factory1 *This, IWICBitmap *target, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1RenderTarget **renderTarget);
    HRESULT WINAPI (*CreateHwndRenderTarget)(q_ID2D1Factory1 *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, const D2D1_HWND_RENDER_TARGET_PROPERTIES *hwndRenderTargetProperties, ID2D1HwndRenderTarget **hwndRenderTarget);
    HRESULT WINAPI (*CreateDxgiSurfaceRenderTarget)(q_ID2D1Factory1 *This, IDXGISurface *dxgiSurface, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1RenderTarget **renderTarget);
    HRESULT WINAPI (*CreateDCRenderTarget)(q_ID2D1Factory1 *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1DCRenderTarget **dcRenderTarget);

    //ID2D1Factory1
    HRESULT WINAPI (*CreateDevice)(q_ID2D1Factory1 *This, IDXGIDevice *dxgiDevice, q_ID2D1Device **d2dDevice);
    HRESULT WINAPI (*CreateStrokeStyle)(q_ID2D1Factory1 *This, CONST D2D1_STROKE_STYLE_PROPERTIES1 *strokeStyleProperties, CONST FLOAT *dashes, UINT32 dashesCount, ID2D1StrokeStyle1 **strokeStyle);
    HRESULT WINAPI (*CreatePathGeometry)(q_ID2D1Factory1 *This, ID2D1PathGeometry1 **pathGeometry);
    HRESULT WINAPI (*CreateDrawingStateBlock)(q_ID2D1Factory1 *This, CONST D2D1_DRAWING_STATE_DESCRIPTION1 *drawingStateDescription, IDWriteRenderingParams *textRenderingParams, ID2D1DrawingStateBlock1 **drawingStateBlock);
    HRESULT WINAPI (*CreateGdiMetafile)(q_ID2D1Factory1 *This, IStream *metafileStream, ID2D1GdiMetafile **metafile);
    HRESULT WINAPI (*RegisterEffectFromStream)(q_ID2D1Factory1 *This, REFCLSID classId, IStream *propertyXml, CONST D2D1_PROPERTY_BINDING *bindings, UINT32 bindingsCount, CONST PD2D1_EFFECT_FACTORY effectFactory);
    HRESULT WINAPI (*RegisterEffectFromString)(q_ID2D1Factory1 *This, REFCLSID classId, PCWSTR propertyXml, CONST D2D1_PROPERTY_BINDING *bindings, UINT32 bindingsCount, CONST PD2D1_EFFECT_FACTORY effectFactory);
    HRESULT WINAPI (*UnregisterEffect)(q_ID2D1Factory1 *This, REFCLSID classId);
    HRESULT WINAPI (*GetRegisteredEffects)(q_ID2D1Factory1 *This, CLSID *effects, UINT32 effectsCount, UINT32 *effectsReturned, UINT32 *effectsRegistered);
    HRESULT WINAPI (*GetEffectProperties)(q_ID2D1Factory1 *This, REFCLSID effectId, ID2D1Properties **properties);
};




/// ID2D1Device
struct q_ID2D1Device
{
    const q_ID2D1Device_vtbl *vtbl;
    ULONG refcount;
};

struct q_ID2D1Device_vtbl
{
    //IUnknown
    HRESULT WINAPI (*QueryInterface)(q_ID2D1Device *This, REFIID riid, void **ppvObject);
    ULONG WINAPI (*AddRef)(q_ID2D1Device *This);
    ULONG WINAPI (*Release)(q_ID2D1Device *This);

    //ID2D1Resource
    void WINAPI (*GetFactory)(q_ID2D1Device *This, ID2D1Factory **factory);

    //ID2D1Device
    HRESULT WINAPI (*CreateDeviceContext)(q_ID2D1Device *This, D2D1_DEVICE_CONTEXT_OPTIONS options, q_ID2D1DeviceContext **deviceContext);
    HRESULT WINAPI (*CreatePrintControl)(q_ID2D1Device *This, IWICImagingFactory *wicFactory, IPrintDocumentPackageTarget *documentTarget, CONST D2D1_PRINT_CONTROL_PROPERTIES *printControlProperties, ID2D1PrintControl **printControl);
    void WINAPI (*SetMaximumTextureMemory)(q_ID2D1Device *This, UINT64 maximumInBytes);
    UINT64 WINAPI (*GetMaximumTextureMemory)(q_ID2D1Device *This);
    void WINAPI (*ClearResources)(q_ID2D1Device *This, UINT32 millisecondsSinceUse);
};




/// ID2D1DeviceContext
struct q_ID2D1DeviceContext
{
    const q_ID2D1DeviceContext_vtbl *vtbl;
    ULONG refcount;
    q_ID2D1Device *parent;

    ID3D11Texture2D *currentTarget;
    D2D1_PRIMITIVE_BLEND primitiveBlend;
};

struct q_ID2D1DeviceContext_vtbl
{
    //IUnknown
    HRESULT WINAPI (*QueryInterface)(q_ID2D1DeviceContext *This, REFIID riid, void **ppvObject);
    ULONG WINAPI (*AddRef)(q_ID2D1DeviceContext *This);
    ULONG WINAPI (*Release)(q_ID2D1DeviceContext *This);

    //ID2D1Resource
    void WINAPI (*GetFactory)(q_ID2D1DeviceContext *This, ID2D1Factory **factory);

    //ID2D1RenderTarget
    HRESULT WINAPI (*_CreateBitmap)(q_ID2D1DeviceContext *This, D2D1_SIZE_U size, const void *srcData, UINT32 pitch, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap);
    HRESULT WINAPI (*_CreateBitmapFromWicBitmap)(q_ID2D1DeviceContext *This, IWICBitmapSource *wicBitmapSource, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap);
    HRESULT WINAPI (*CreateSharedBitmap)(q_ID2D1DeviceContext *This, REFIID riid, void *data, const D2D1_BITMAP_PROPERTIES *bitmapProperties, ID2D1Bitmap **bitmap);
    HRESULT WINAPI (*_CreateBitmapBrush)(q_ID2D1DeviceContext *This, ID2D1Bitmap *bitmap, const D2D1_BITMAP_BRUSH_PROPERTIES *bitmapBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1BitmapBrush **bitmapBrush);
    HRESULT WINAPI (*CreateSolidColorBrush)(q_ID2D1DeviceContext *This, const D2D1_COLOR_F *color, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1SolidColorBrush **solidColorBrush);
    HRESULT WINAPI (*_CreateGradientStopCollection)(q_ID2D1DeviceContext *This, const D2D1_GRADIENT_STOP *gradientStops, UINT gradientStopsCount, D2D1_GAMMA colorInterpolationGamma, D2D1_EXTEND_MODE extendMode, ID2D1GradientStopCollection **gradientStopCollection);
    HRESULT WINAPI (*CreateLinearGradientBrush)(q_ID2D1DeviceContext *This, const D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES *linearGradientBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1GradientStopCollection *gradientStopCollection, ID2D1LinearGradientBrush **linearGradientBrush);
    HRESULT WINAPI (*CreateRadialGradientBrush)(q_ID2D1DeviceContext *This, const D2D1_RADIAL_GRADIENT_BRUSH_PROPERTIES *radialGradientBrushProperties, const D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1GradientStopCollection *gradientStopCollection, ID2D1RadialGradientBrush **radialGradientBrush);
    HRESULT WINAPI (*CreateCompatibleRenderTarget)(q_ID2D1DeviceContext *This, const D2D1_SIZE_F *desiredSize, const D2D1_SIZE_U *desiredPixelSize, const D2D1_PIXEL_FORMAT *desiredFormat, D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS options, ID2D1BitmapRenderTarget **bitmapRenderTarget);
    HRESULT WINAPI (*CreateLayer)(q_ID2D1DeviceContext *This, const D2D1_SIZE_F *size, ID2D1Layer **layer);
    HRESULT WINAPI (*CreateMesh)(q_ID2D1DeviceContext *This, ID2D1Mesh **mesh);
    void WINAPI (*DrawLine)(q_ID2D1DeviceContext *This, D2D1_POINT_2F point0, D2D1_POINT_2F point1, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle);
    void WINAPI (*DrawRectangle)(q_ID2D1DeviceContext *This, const D2D1_RECT_F *rect, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle);
    void WINAPI (*FillRectangle)(q_ID2D1DeviceContext *This, const D2D1_RECT_F *rect, ID2D1Brush *brush);
    void WINAPI (*DrawRoundedRectangle)(q_ID2D1DeviceContext *This, const D2D1_ROUNDED_RECT *roundedRect, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle);
    void WINAPI (*FillRoundedRectangle)(q_ID2D1DeviceContext *This, const D2D1_ROUNDED_RECT *roundedRect, ID2D1Brush *brush);
    void WINAPI (*DrawEllipse)(q_ID2D1DeviceContext *This, const D2D1_ELLIPSE *ellipse, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle);
    void WINAPI (*FillEllipse)(q_ID2D1DeviceContext *This, const D2D1_ELLIPSE *ellipse, ID2D1Brush *brush);
    void WINAPI (*DrawGeometry)(q_ID2D1DeviceContext *This, ID2D1Geometry *geometry, ID2D1Brush *brush, FLOAT strokeWidth, ID2D1StrokeStyle *strokeStyle);
    void WINAPI (*FillGeometry)(q_ID2D1DeviceContext *This, ID2D1Geometry *geometry, ID2D1Brush *brush, ID2D1Brush *opacityBrush);
    void WINAPI (*FillMesh)(q_ID2D1DeviceContext *This, ID2D1Mesh *mesh, ID2D1Brush *brush);
    void WINAPI (*_FillOpacityMask)(q_ID2D1DeviceContext *This, ID2D1Bitmap *opacityMask, ID2D1Brush *brush, D2D1_OPACITY_MASK_CONTENT content, const D2D1_RECT_F *destinationRectangle, const D2D1_RECT_F *sourceRectangle);
    void WINAPI (*_DrawBitmap)(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *bitmap, const D2D1_RECT_F *destinationRectangle, FLOAT opacity, D2D1_BITMAP_INTERPOLATION_MODE interpolationMode, const D2D1_RECT_F *sourceRectangle);
    void WINAPI (*DrawText)(q_ID2D1DeviceContext *This, const WCHAR *string, UINT stringLength, IDWriteTextFormat *textFormat, const D2D1_RECT_F *layoutRect, ID2D1Brush *defaultForegroundBrush, D2D1_DRAW_TEXT_OPTIONS options, DWRITE_MEASURING_MODE measuringMode);
    void WINAPI (*DrawTextLayout)(q_ID2D1DeviceContext *This, D2D1_POINT_2F origin, IDWriteTextLayout *textLayout, ID2D1Brush *defaultForegroundBrush, D2D1_DRAW_TEXT_OPTIONS options);
    void WINAPI (*_DrawGlyphRun)(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, const DWRITE_GLYPH_RUN *glyphRun, ID2D1Brush *foregroundBrush, DWRITE_MEASURING_MODE measuringMode);
    void WINAPI (*SetTransform)(q_ID2D1DeviceContext *This, const D2D1_MATRIX_3X2_F *transform);
    void WINAPI (*GetTransform)(q_ID2D1DeviceContext *This, D2D1_MATRIX_3X2_F *transform);
    void WINAPI (*SetAntialiasMode)(q_ID2D1DeviceContext *This, D2D1_ANTIALIAS_MODE antialiasMode);
    D2D1_ANTIALIAS_MODE WINAPI (*GetAntialiasMode)(q_ID2D1DeviceContext *This);
    void WINAPI (*SetTextAntialiasMode)(q_ID2D1DeviceContext *This, D2D1_TEXT_ANTIALIAS_MODE textAntialiasMode);
    D2D1_TEXT_ANTIALIAS_MODE WINAPI (*GetTextAntialiasMode)(q_ID2D1DeviceContext *This);
    void WINAPI (*SetTextRenderingParams)(q_ID2D1DeviceContext *This, IDWriteRenderingParams *textRenderingParams);
    void WINAPI (*GetTextRenderingParams)(q_ID2D1DeviceContext *This, IDWriteRenderingParams **textRenderingParams);
    void WINAPI (*SetTags)(q_ID2D1DeviceContext *This, D2D1_TAG tag1, D2D1_TAG tag2);
    void WINAPI (*GetTags)(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2);
    void WINAPI (*_PushLayer)(q_ID2D1DeviceContext *This, const D2D1_LAYER_PARAMETERS *layerParameters, ID2D1Layer *layer);
    void WINAPI (*PopLayer)(q_ID2D1DeviceContext *This);
    HRESULT WINAPI (*Flush)(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2);
    void WINAPI (*SaveDrawingState)(q_ID2D1DeviceContext *This, ID2D1DrawingStateBlock *drawingStateBlock);
    void WINAPI (*RestoreDrawingState)(q_ID2D1DeviceContext *This, ID2D1DrawingStateBlock *drawingStateBlock);
    void WINAPI (*PushAxisAlignedClip)(q_ID2D1DeviceContext *This, const D2D1_RECT_F *clipRect, D2D1_ANTIALIAS_MODE antialiasMode);
    void WINAPI (*PopAxisAlignedClip)(q_ID2D1DeviceContext *This);
    void WINAPI (*Clear)(q_ID2D1DeviceContext *This, const D2D1_COLOR_F *clearColor);
    void WINAPI (*BeginDraw)(q_ID2D1DeviceContext *This);
    HRESULT WINAPI (*EndDraw)(q_ID2D1DeviceContext *This, D2D1_TAG *tag1, D2D1_TAG *tag2);
    D2D1_PIXEL_FORMAT WINAPI (*GetPixelFormat)(q_ID2D1DeviceContext *This);
    void WINAPI (*SetDpi)(q_ID2D1DeviceContext *This, FLOAT dpiX, FLOAT dpiY);
    void WINAPI (*GetDpi)(q_ID2D1DeviceContext *This, FLOAT *dpiX, FLOAT *dpiY);
    D2D1_SIZE_F WINAPI (*GetSize)(q_ID2D1DeviceContext *This);
    D2D1_SIZE_U WINAPI (*GetPixelSize)(q_ID2D1DeviceContext *This);
    UINT32 WINAPI (*GetMaximumBitmapSize)(q_ID2D1DeviceContext *This);
    BOOL WINAPI (*IsSupported)(q_ID2D1DeviceContext *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties);

    //ID2D1DeviceContext
    HRESULT WINAPI (*CreateBitmap)(q_ID2D1DeviceContext *This, D2D1_SIZE_U size, CONST void *sourceData, UINT32 pitch, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, ID2D1Bitmap1 **bitmap);
    HRESULT WINAPI (*CreateBitmapFromWicBitmap)(q_ID2D1DeviceContext *This, IWICBitmapSource *wicBitmapSource, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, ID2D1Bitmap1 **bitmap);
    HRESULT WINAPI (*CreateColorContext)(q_ID2D1DeviceContext *This, D2D1_COLOR_SPACE space, CONST BYTE *profile, UINT32 profileSize, ID2D1ColorContext **colorContext);
    HRESULT WINAPI (*CreateColorContextFromFilename)(q_ID2D1DeviceContext *This, PCWSTR filename, ID2D1ColorContext **colorContext);
    HRESULT WINAPI (*CreateColorContextFromWicColorContext)(q_ID2D1DeviceContext *This, IWICColorContext *wicColorContext, ID2D1ColorContext **colorContext);
    HRESULT WINAPI (*CreateBitmapFromDxgiSurface)(q_ID2D1DeviceContext *This, IDXGISurface *surface, CONST D2D1_BITMAP_PROPERTIES1 *bitmapProperties, q_ID2D1Bitmap1 **bitmap);
    HRESULT WINAPI (*CreateEffect)(q_ID2D1DeviceContext *This, REFCLSID effectId, ID2D1Effect **effect);
    HRESULT WINAPI (*CreateGradientStopCollection)(q_ID2D1DeviceContext *This, CONST D2D1_GRADIENT_STOP *straightAlphaGradientStops, UINT32 straightAlphaGradientStopsCount, D2D1_COLOR_SPACE preInterpolationSpace, D2D1_COLOR_SPACE postInterpolationSpace, D2D1_BUFFER_PRECISION bufferPrecision, D2D1_EXTEND_MODE extendMode, D2D1_COLOR_INTERPOLATION_MODE colorInterpolationMode, ID2D1GradientStopCollection1 **gradientStopCollection1);
    HRESULT WINAPI (*CreateImageBrush)(q_ID2D1DeviceContext *This, struct ID2D1Image *image, CONST D2D1_IMAGE_BRUSH_PROPERTIES *imageBrushProperties, CONST D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1ImageBrush **imageBrush);
    HRESULT WINAPI (*CreateBitmapBrush)(q_ID2D1DeviceContext *This, ID2D1Bitmap *bitmap, CONST D2D1_BITMAP_BRUSH_PROPERTIES1 *bitmapBrushProperties, CONST D2D1_BRUSH_PROPERTIES *brushProperties, ID2D1BitmapBrush1 **bitmapBrush);
    HRESULT WINAPI (*CreateCommandList)(q_ID2D1DeviceContext *This, ID2D1CommandList **commandList);
    BOOL WINAPI (*IsDxgiFormatSupported)(q_ID2D1DeviceContext *This, DXGI_FORMAT format);
    BOOL WINAPI (*IsBufferPrecisionSupported)(q_ID2D1DeviceContext *This, D2D1_BUFFER_PRECISION bufferPrecision);
    HRESULT WINAPI (*GetImageLocalBounds)(q_ID2D1DeviceContext *This, struct ID2D1Image *image, D2D1_RECT_F *localBounds);
    HRESULT WINAPI (*GetImageWorldBounds)(q_ID2D1DeviceContext *This, struct ID2D1Image *image, D2D1_RECT_F *worldBounds);
    HRESULT WINAPI (*GetGlyphRunWorldBounds)(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, CONST DWRITE_GLYPH_RUN *glyphRun, DWRITE_MEASURING_MODE measuringMode, D2D1_RECT_F *bounds);
    void WINAPI (*GetDevice)(q_ID2D1DeviceContext *This, ID2D1Device **device);
    void WINAPI (*SetTarget)(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *image);
    void WINAPI (*GetTarget)(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 **image);
    void WINAPI (*SetRenderingControls)(q_ID2D1DeviceContext *This, CONST D2D1_RENDERING_CONTROLS *renderingControls);
    void WINAPI (*GetRenderingControls)(q_ID2D1DeviceContext *This, D2D1_RENDERING_CONTROLS *renderingControls);
    void WINAPI (*SetPrimitiveBlend)(q_ID2D1DeviceContext *This, D2D1_PRIMITIVE_BLEND primitiveBlend);
    D2D1_PRIMITIVE_BLEND WINAPI (*GetPrimitiveBlend)(q_ID2D1DeviceContext *This);
    void WINAPI (*SetUnitMode)(q_ID2D1DeviceContext *This, D2D1_UNIT_MODE unitMode);
    D2D1_UNIT_MODE WINAPI (*GetUnitMode)(q_ID2D1DeviceContext *This);
    void WINAPI (*DrawGlyphRun)(q_ID2D1DeviceContext *This, D2D1_POINT_2F baselineOrigin, CONST DWRITE_GLYPH_RUN *glyphRun, CONST DWRITE_GLYPH_RUN_DESCRIPTION *glyphRunDescription, ID2D1Brush *foregroundBrush, DWRITE_MEASURING_MODE measuringMode);
    void WINAPI (*DrawImage)(q_ID2D1DeviceContext *This, struct ID2D1Image *image, CONST D2D1_POINT_2F *targetOffset, CONST D2D1_RECT_F *imageRectangle, D2D1_INTERPOLATION_MODE interpolationMode, D2D1_COMPOSITE_MODE compositeMode);
    void WINAPI (*DrawGdiMetafile)(q_ID2D1DeviceContext *This, ID2D1GdiMetafile *gdiMetafile, CONST D2D1_POINT_2F *targetOffset);
    void WINAPI (*DrawBitmap)(q_ID2D1DeviceContext *This, q_ID2D1Bitmap1 *bitmap, CONST D2D1_RECT_F *destinationRectangle, FLOAT opacity, D2D1_INTERPOLATION_MODE interpolationMode, CONST D2D1_RECT_F *sourceRectangle, CONST D2D1_MATRIX_4X4_F *perspectiveTransform);
    void WINAPI (*PushLayer)(q_ID2D1DeviceContext *This, CONST D2D1_LAYER_PARAMETERS1 *layerParameters, ID2D1Layer *layer);
    HRESULT WINAPI (*InvalidateEffectInputRectangle)(q_ID2D1DeviceContext *This, ID2D1Effect *effect, UINT32 input, CONST D2D1_RECT_F *inputRectangle);
    HRESULT WINAPI (*GetEffectInvalidRectangleCount)(q_ID2D1DeviceContext *This, ID2D1Effect *effect, UINT32 *rectangleCount);
    HRESULT WINAPI (*GetEffectInvalidRectangles)(q_ID2D1DeviceContext *This, ID2D1Effect *effect, D2D1_RECT_F *rectangles, UINT32 rectanglesCount);
    HRESULT WINAPI (*GetEffectRequiredInputRectangles)(q_ID2D1DeviceContext *This, ID2D1Effect *renderEffect, CONST D2D1_RECT_F *renderImageRectangle, CONST D2D1_EFFECT_INPUT_DESCRIPTION *inputDescriptions, D2D1_RECT_F *requiredInputRects, UINT32 inputCount);
    void WINAPI (*FillOpacityMask)(q_ID2D1DeviceContext *This, ID2D1Bitmap *opacityMask, ID2D1Brush *brush, CONST D2D1_RECT_F *destinationRectangle, CONST D2D1_RECT_F *sourceRectangle);
};




/// ID2D1Bitmap1
struct q_ID2D1Bitmap1
{
    const q_ID2D1Bitmap1_vtbl *vtbl;
    ULONG refcount;
    q_ID2D1DeviceContext *parent;

    //IDXGISurface *surface;
    ID3D11Texture2D *texture;
};

struct q_ID2D1Bitmap1_vtbl
{
    //IUnknown
    HRESULT WINAPI (*QueryInterface)(q_ID2D1Bitmap1 *This, REFIID riid, void **ppvObject);
    ULONG WINAPI (*AddRef)(q_ID2D1Bitmap1 *This);
    ULONG WINAPI (*Release)(q_ID2D1Bitmap1 *This);

    //ID2D1Resource
    void WINAPI (*GetFactory)(q_ID2D1Bitmap1 *This, ID2D1Factory **factory);

    //ID2D1Bitmap
    D2D1_SIZE_F WINAPI (*GetSize)(q_ID2D1Bitmap1 *This);
    D2D1_SIZE_U WINAPI (*GetPixelSize)(q_ID2D1Bitmap1 *This);
    D2D1_PIXEL_FORMAT WINAPI (*GetPixelFormat)(q_ID2D1Bitmap1 *This);
    void WINAPI (*GetDpi)(q_ID2D1Bitmap1 *This, FLOAT *dpiX, FLOAT *dpiY);
    HRESULT WINAPI (*CopyFromBitmap)(q_ID2D1Bitmap1 *This, const D2D1_POINT_2U *destPoint, ID2D1Bitmap *bitmap, const D2D1_RECT_U *srcRect);
    HRESULT WINAPI (*CopyFromRenderTarget)(q_ID2D1Bitmap1 *This, const D2D1_POINT_2U *destPoint, ID2D1RenderTarget *renderTarget, const D2D1_RECT_U *srcRect);
    HRESULT WINAPI (*CopyFromMemory)(q_ID2D1Bitmap1 *This, const D2D1_RECT_U *dstRect, const void *srcData, UINT32 pitch);

    //ID2D1Bitmap1
    void WINAPI (*GetColorContext)(q_ID2D1Bitmap1 *This, ID2D1ColorContext **colorContext);
    D2D1_BITMAP_OPTIONS WINAPI (*GetOptions)(q_ID2D1Bitmap1 *This);
    HRESULT WINAPI (*GetSurface)(q_ID2D1Bitmap1 *This, IDXGISurface **dxgiSurface);
    HRESULT WINAPI (*Map)(q_ID2D1Bitmap1 *This, D2D1_MAP_OPTIONS options, D2D1_MAPPED_RECT *mappedRect);
    HRESULT WINAPI (*Unmap)(q_ID2D1Bitmap1 *This);
};





/// internal rendering implementation
HRESULT GetDxgiSurfaceToTexture(IDXGISurface *surface, ID3D11Texture2D **texture);
//void DrawRectBitmap(ID3D11Texture2D *src, ID3D11Texture2D *dest, float x, float y, float w, float h);
void DrawRectBitmap(ID3D11Texture2D *dest, ID3D11Texture2D *src, const D2D1_RECT_F *destRect, const D2D1_RECT_F *srcRect, int filtering, int blending);
void ClearBitmap(ID3D11Texture2D *target, const float *color);


#ifdef __cplusplus
}
#endif
