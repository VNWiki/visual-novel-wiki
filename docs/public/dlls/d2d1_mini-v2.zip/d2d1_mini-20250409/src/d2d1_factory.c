#include <stdio.h>
#include <stdlib.h>

#include "mini_d2d1.h"



HRESULT WINAPI q_D2D1CreateFactory(D2D1_FACTORY_TYPE factoryType, REFIID riid, const D2D1_FACTORY_OPTIONS *pFactoryOptions, void **ppIFactory)
{
    q_ID2D1Factory1 *factory;

    debug_printf("D2D1CreateFactory\n");

    factory = (q_ID2D1Factory1*)malloc(sizeof(q_ID2D1Factory1));
    factory->vtbl = &_ID2D1Factory1_vtbl;
    factory->refcount = 1;

    *ppIFactory = factory;
    return S_OK;
}



//IUnknown
HRESULT WINAPI q_ID2D1Factory1_QueryInterface(q_ID2D1Factory1 *This, REFIID riid, void **ppvObject)
{
    LOGNOP;
}
ULONG WINAPI q_ID2D1Factory1_AddRef(q_ID2D1Factory1 *This)
{
    This->refcount++;
    return This->refcount;
}
ULONG WINAPI q_ID2D1Factory1_Release(q_ID2D1Factory1 *This)
{
    ULONG ret = --This->refcount;
    if (ret == 0)
    {
        debug_printf("freeing ID2D1Factory\n");
        free(This);
    }
    return ret;
}

//ID2D1Factory
HRESULT WINAPI q_ID2D1Factory1_ReloadSystemMetrics(q_ID2D1Factory1 *This)
{
    LOGNOP;
}
void WINAPI q_ID2D1Factory1_GetDesktopDpi(q_ID2D1Factory1 *This, FLOAT *dpiX, FLOAT *dpiY)
{
}
HRESULT WINAPI q_ID2D1Factory1_CreateRectangleGeometry(q_ID2D1Factory1 *This, const D2D1_RECT_F *rectangle, ID2D1RectangleGeometry **rectangleGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateRoundedRectangleGeometry(q_ID2D1Factory1 *This, const D2D1_ROUNDED_RECT *roundedRectangle, ID2D1RoundedRectangleGeometry **roundedRectangleGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateEllipseGeometry(q_ID2D1Factory1 *This, const D2D1_ELLIPSE *ellipse, ID2D1EllipseGeometry **ellipseGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateGeometryGroup(q_ID2D1Factory1 *This, D2D1_FILL_MODE fillMode, ID2D1Geometry **geometries, UINT geometriesCount, ID2D1GeometryGroup **geometryGroup)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateTransformedGeometry(q_ID2D1Factory1 *This, ID2D1Geometry *sourceGeometry, const D2D1_MATRIX_3X2_F *transform, ID2D1TransformedGeometry **transformedGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1__CreatePathGeometry(q_ID2D1Factory1 *This, ID2D1PathGeometry **pathGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1__CreateStrokeStyle(q_ID2D1Factory1 *This, const D2D1_STROKE_STYLE_PROPERTIES *strokeStyleProperties, const FLOAT *dashes, UINT dashesCount, ID2D1StrokeStyle **strokeStyle)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1__CreateDrawingStateBlock(q_ID2D1Factory1 *This, const D2D1_DRAWING_STATE_DESCRIPTION *drawingStateDescription, IDWriteRenderingParams *textRenderingParams, ID2D1DrawingStateBlock **drawingStateBlock)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateWicBitmapRenderTarget(q_ID2D1Factory1 *This, IWICBitmap *target, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1RenderTarget **renderTarget)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateHwndRenderTarget(q_ID2D1Factory1 *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, const D2D1_HWND_RENDER_TARGET_PROPERTIES *hwndRenderTargetProperties, ID2D1HwndRenderTarget **hwndRenderTarget)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateDxgiSurfaceRenderTarget(q_ID2D1Factory1 *This, IDXGISurface *dxgiSurface, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1RenderTarget **renderTarget)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateDCRenderTarget(q_ID2D1Factory1 *This, const D2D1_RENDER_TARGET_PROPERTIES *renderTargetProperties, ID2D1DCRenderTarget **dcRenderTarget)
{
    LOGNOP;
}

//ID2D1Factory1
HRESULT WINAPI q_ID2D1Factory1_CreateDevice(q_ID2D1Factory1 *This, IDXGIDevice *dxgiDevice, q_ID2D1Device **d2dDevice)
{
    q_ID2D1Device *device;

    debug_printf("CreateDevice\n");
    device = (q_ID2D1Device*)malloc(sizeof(q_ID2D1Device));
    device->vtbl = &_ID2D1Device_vtbl;
    device->refcount = 1;

    *d2dDevice = device;
    return S_OK;
}
HRESULT WINAPI q_ID2D1Factory1_CreateStrokeStyle(q_ID2D1Factory1 *This, CONST D2D1_STROKE_STYLE_PROPERTIES1 *strokeStyleProperties, CONST FLOAT *dashes, UINT32 dashesCount, ID2D1StrokeStyle1 **strokeStyle)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreatePathGeometry(q_ID2D1Factory1 *This, ID2D1PathGeometry1 **pathGeometry)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateDrawingStateBlock(q_ID2D1Factory1 *This, CONST D2D1_DRAWING_STATE_DESCRIPTION1 *drawingStateDescription, IDWriteRenderingParams *textRenderingParams, ID2D1DrawingStateBlock1 **drawingStateBlock)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_CreateGdiMetafile(q_ID2D1Factory1 *This, IStream *metafileStream, ID2D1GdiMetafile **metafile)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_RegisterEffectFromStream(q_ID2D1Factory1 *This, REFCLSID classId, IStream *propertyXml, CONST D2D1_PROPERTY_BINDING *bindings, UINT32 bindingsCount, CONST PD2D1_EFFECT_FACTORY effectFactory)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_RegisterEffectFromString(q_ID2D1Factory1 *This, REFCLSID classId, PCWSTR propertyXml, CONST D2D1_PROPERTY_BINDING *bindings, UINT32 bindingsCount, CONST PD2D1_EFFECT_FACTORY effectFactory)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_UnregisterEffect(q_ID2D1Factory1 *This, REFCLSID classId)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_GetRegisteredEffects(q_ID2D1Factory1 *This, CLSID *effects, UINT32 effectsCount, UINT32 *effectsReturned, UINT32 *effectsRegistered)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Factory1_GetEffectProperties(q_ID2D1Factory1 *This, REFCLSID effectId, ID2D1Properties **properties)
{
    LOGNOP;
}



const q_ID2D1Factory1_vtbl _ID2D1Factory1_vtbl =
{
    //IUnknown
    &q_ID2D1Factory1_QueryInterface,
    &q_ID2D1Factory1_AddRef,
    &q_ID2D1Factory1_Release,

    //ID2D1Factory
    &q_ID2D1Factory1_ReloadSystemMetrics,
    &q_ID2D1Factory1_GetDesktopDpi,
    &q_ID2D1Factory1_CreateRectangleGeometry,
    &q_ID2D1Factory1_CreateRoundedRectangleGeometry,
    &q_ID2D1Factory1_CreateEllipseGeometry,
    &q_ID2D1Factory1_CreateGeometryGroup,
    &q_ID2D1Factory1_CreateTransformedGeometry,
    &q_ID2D1Factory1__CreatePathGeometry,
    &q_ID2D1Factory1__CreateStrokeStyle,
    &q_ID2D1Factory1__CreateDrawingStateBlock,
    &q_ID2D1Factory1_CreateWicBitmapRenderTarget,
    &q_ID2D1Factory1_CreateHwndRenderTarget,
    &q_ID2D1Factory1_CreateDxgiSurfaceRenderTarget,
    &q_ID2D1Factory1_CreateDCRenderTarget,

    //ID2D1Factory1
    &q_ID2D1Factory1_CreateDevice,
    &q_ID2D1Factory1_CreateStrokeStyle,
    &q_ID2D1Factory1_CreatePathGeometry,
    &q_ID2D1Factory1_CreateDrawingStateBlock,
    &q_ID2D1Factory1_CreateGdiMetafile,
    &q_ID2D1Factory1_RegisterEffectFromStream,
    &q_ID2D1Factory1_RegisterEffectFromString,
    &q_ID2D1Factory1_UnregisterEffect,
    &q_ID2D1Factory1_GetRegisteredEffects,
    &q_ID2D1Factory1_GetEffectProperties
};
