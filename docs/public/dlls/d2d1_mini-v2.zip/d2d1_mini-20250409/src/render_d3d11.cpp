#include <stdio.h>

#include "mini_d2d1.h"
#include "shaderbin_vertex.h"
#include "shaderbin_pixel.h"

ID3D11Device *d3d11device;
ID3D11DeviceContext *d3d11context;

ID3D11VertexShader *vertexshader;
ID3D11PixelShader *pixelshader;
ID3D11InputLayout *inputlayout;

ID3D11Buffer *vertbuffer;
ID3D11Texture2D *texture;
ID3D11SamplerState *samplerLinear, *samplerPoint;
ID3D11BlendState *blend;


static int IsInitDone;
int initD3DResource();


#define NOINLINE __attribute__((noinline))
#define UNUSED __attribute__((unused))



const D3D11_INPUT_ELEMENT_DESC layout[] =
{
    { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,    0,  0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,       0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    { "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 20, D3D11_INPUT_PER_VERTEX_DATA, 0 },
};


typedef struct
{
    struct { float x, y, z; } pos;
    struct { float u, v; } texcoord;
    struct { float r, g, b, a; } color;
} VERTDATA;

#define _VERTALPHA 1.0f

#define NORMCOORD(point, denom) (2.0f * (float)(point) / (float)(denom) - 1.0f)
#define NORMUV(point, denom) ((float)(point) / (float)(denom))


NOINLINE static HRESULT setVertices(const D2D1_RECT_F *destRect, const D2D1_RECT_F *srcRect, float dest_txW, float dest_txH, float src_txW, float src_txH)
{
    HRESULT ret;
    D3D11_MAPPED_SUBRESOURCE mapped;

    //vertex pos for destination quad
    const float dL = NORMCOORD(destRect->left, dest_txW);
    const float dR = NORMCOORD(destRect->right, dest_txW);
    const float dT = NORMCOORD(destRect->top, dest_txH);
    const float dB = NORMCOORD(destRect->bottom, dest_txH);

    //UV coordinates for source texture
    const float sL = NORMUV(srcRect->left, src_txW);
    const float sR = NORMUV(srcRect->right, src_txW);
    const float sT = NORMUV(srcRect->top, src_txH);
    const float sB = NORMUV(srcRect->bottom, src_txH);

    const VERTDATA vertices[] =
    {
        { { dL, -dT, 0.0f }, { sL, sT }, { 1.0f, 1.0f, 1.0f, _VERTALPHA } }, //NW
        { { dR, -dT, 0.0f }, { sR, sT }, { 0.0f, 1.0f, 0.0f, _VERTALPHA } }, //NE
        { { dL, -dB, 0.0f }, { sL, sB }, { 1.0f, 0.0f, 0.0f, _VERTALPHA } }, //SW
        { { dR, -dB, 0.0f }, { sR, sB }, { 0.0f, 0.0f, 1.0f, _VERTALPHA } }, //SE
    };

    ret = d3d11context->Map(vertbuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
    if (ret == S_OK)
    {
        memcpy(mapped.pData, vertices, sizeof(vertices));
        d3d11context->Unmap(vertbuffer, 0);
    }
    else { debug_printf("Map vertbuffer error = %lX\n", ret); }

    return ret;
}


void DrawRectBitmap(ID3D11Texture2D *dest, ID3D11Texture2D *src, const D2D1_RECT_F *destRect, const D2D1_RECT_F *srcRect, int filtering, int blending)
{
    ID3D11ShaderResourceView *srv;
    ID3D11RenderTargetView *rtv, *prev_rtv;
    ID3D11SamplerState *sampler;

    D3D11_TEXTURE2D_DESC texdesc_dest, texdesc_src;
    D3D11_VIEWPORT viewport;

    D2D1_RECT_F tmp_destRect, tmp_srcRect;

    const UINT vertstride = sizeof(VERTDATA);
    const UINT vertoffset = 0;

    debug_printf("DrawRectBitmap | src %p | dest %p | blend %d\n", src, dest, blending);
    if (src == NULL) { debug_printf("... null src\n"); return; }
    if (dest == NULL) { debug_printf("... null dest\n"); return; }

    //init
    src->GetDevice(&d3d11device);
    d3d11device->Release();

    d3d11device->GetImmediateContext(&d3d11context);
    d3d11context->Release();

    if (!IsInitDone) { initD3DResource(); }

    //--rectangle dimensions
    dest->GetDesc(&texdesc_dest);
    src->GetDesc(&texdesc_src);

    if (destRect == NULL)
    {
        destRect = &tmp_destRect;
        tmp_destRect.left = 0;
        tmp_destRect.top = 0;
        tmp_destRect.right = texdesc_dest.Width;
        tmp_destRect.bottom = texdesc_dest.Height;
    }

    if (srcRect == NULL)
    {
        srcRect = &tmp_srcRect;
        tmp_srcRect.left = 0;
        tmp_srcRect.top = 0;
        tmp_srcRect.right = texdesc_src.Width;
        tmp_srcRect.bottom = texdesc_src.Height;
    }


    //init vertex geometry
    setVertices(destRect, srcRect, texdesc_dest.Width, texdesc_dest.Height, texdesc_src.Width, texdesc_src.Height);

    //debug_printf("... at (%.0f,%.0f) is %.0fx%.0f  in  %ux%u\n", x, y, w, h, texdesc.Width, texdesc.Height);

    //viewport
    viewport.TopLeftX = 0;
    viewport.TopLeftY = 0;
    viewport.Width = texdesc_dest.Width;
    viewport.Height = texdesc_dest.Height;
    viewport.MinDepth = 0;
    viewport.MaxDepth = 1.0f;

    //filtering type
    if (filtering == 0) { sampler = samplerPoint; }
    else { sampler = samplerLinear; }

    //prepare temp elements
    d3d11device->CreateShaderResourceView(src, NULL, &srv);
    d3d11device->CreateRenderTargetView(dest, NULL, &rtv);

    //prepare
    d3d11context->IASetInputLayout(inputlayout);
    d3d11context->IASetVertexBuffers(0, 1, &vertbuffer, &vertstride, &vertoffset);
    d3d11context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

    d3d11context->VSSetShader(vertexshader, NULL, 0);
    d3d11context->PSSetShader(pixelshader, NULL, 0);

    d3d11context->PSSetShaderResources(0, 1, &srv);
    d3d11context->PSSetSamplers(0, 1, &sampler);
    d3d11context->OMSetBlendState(blending ? blend : NULL, NULL, 0xFFFFFFFF);

    d3d11context->OMGetRenderTargets(1, &prev_rtv, NULL);
    d3d11context->OMSetRenderTargets(1, &rtv, NULL);
    d3d11context->RSSetViewports(1, &viewport);

    //draw
    d3d11context->Draw(4, 0);

    //cleanup
    d3d11context->OMSetRenderTargets(1, &prev_rtv, NULL);

    srv->Release();
    rtv->Release();
    if (prev_rtv) { prev_rtv->Release(); }
}

//const float bgcolor[4] = {1.0f,0,0,1.0f};
void ClearBitmap(ID3D11Texture2D *target, const float *color)
{
    ID3D11RenderTargetView *rtv, *prev_rtv;

    if (d3d11device == NULL)
    {
        target->GetDevice(&d3d11device);
        d3d11device->GetImmediateContext(&d3d11context);
    }

    d3d11device->CreateRenderTargetView(target, NULL, &rtv);
    d3d11context->OMGetRenderTargets(1, &prev_rtv, NULL);
    d3d11context->OMSetRenderTargets(1, &rtv, NULL);

    d3d11context->ClearRenderTargetView(rtv, color); //<----

    d3d11context->OMSetRenderTargets(1, &prev_rtv, NULL);
    if (rtv) { rtv->Release(); }
    if (prev_rtv) { prev_rtv->Release(); }
}


HRESULT GetDxgiSurfaceToTexture(IDXGISurface *surface, ID3D11Texture2D **texture)
{
    HRESULT ret;
    debug_printf(" >>> GetDxgiSurfaceToTexture\n");
    ret = surface->QueryInterface(IID_ID3D11Texture2D, (void**)texture);
    if (ret != S_OK) { *texture = NULL; debug_printf(" .... no ptr\n"); }
    return ret;
}


int initD3DResource()
{
    HRESULT ret;

    D3D11_BUFFER_DESC bufferdesc;
    D3D11_SAMPLER_DESC samplerdesc;
    D3D11_BLEND_DESC blenddesc;

    //flag set
    IsInitDone = 1;
    debug_printf("starting resource init\n");

    /// --- shaders ---
    //load embedded shaders
    ret = d3d11device->CreateInputLayout(layout, sizeof(layout) / sizeof(layout[0]), shaderbin_vertex, sizeof(shaderbin_vertex), &inputlayout);
    debug_printf("CreateInputLayout = %lX\n", ret);
    if (ret != S_OK) { return 1; }

    ret = d3d11device->CreateVertexShader(shaderbin_vertex, sizeof(shaderbin_vertex), NULL, &vertexshader);
    debug_printf("CreateVertexShader = %lX\n", ret);
    if (ret != S_OK) { return 1; }

    ret = d3d11device->CreatePixelShader(shaderbin_pixel, sizeof(shaderbin_pixel), NULL, &pixelshader);
    debug_printf("CreatePixelShader = %lX\n", ret);
    if (ret != S_OK) { return 2; }


    /// --- vertex buffer ---
    bufferdesc.ByteWidth = sizeof(VERTDATA) * 4;
    bufferdesc.Usage = D3D11_USAGE_DYNAMIC;
    bufferdesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    bufferdesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    bufferdesc.MiscFlags = 0;

    ret = d3d11device->CreateBuffer(&bufferdesc, NULL, &vertbuffer);
    debug_printf("CreateBuffer for vertex = %lX\n", ret);
    if (ret != S_OK) { return 3; }


    /// --- sampler ---
    samplerdesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    samplerdesc.AddressU = samplerdesc.AddressV = samplerdesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    samplerdesc.MipLODBias = 0;
    samplerdesc.MaxAnisotropy = D3D11_MAX_MAXANISOTROPY;
    samplerdesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
    samplerdesc.BorderColor[0] = 0;
    samplerdesc.BorderColor[1] = 0;
    samplerdesc.BorderColor[2] = 0;
    samplerdesc.BorderColor[3] = 0;
    samplerdesc.MinLOD = 0;
    samplerdesc.MaxLOD = D3D11_FLOAT32_MAX;

    //linear sampler
    ret = d3d11device->CreateSamplerState(&samplerdesc, &samplerLinear);
    debug_printf("CreateSamplerState [linear] = %lX\n", ret);
    if (ret != S_OK) { return 6; }

    //point sampler
    samplerdesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
    ret = d3d11device->CreateSamplerState(&samplerdesc, &samplerPoint);
    debug_printf("CreateSamplerState [point] = %lX\n", ret);
    if (ret != S_OK) { return 6; }


    /// --- blend state ---
    memset(&blenddesc, 0, sizeof(D3D11_BLEND_DESC));
    blenddesc.AlphaToCoverageEnable = 0;
    blenddesc.IndependentBlendEnable = 0;
    blenddesc.RenderTarget[0].BlendEnable = TRUE;
    blenddesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
    blenddesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    blenddesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    blenddesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    blenddesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
    blenddesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    blenddesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

    ret = d3d11device->CreateBlendState(&blenddesc, &blend);
    debug_printf("CreateBlendState = %lX\n", ret);
    if (ret != S_OK) { return 7; }



    debug_printf(">>>>> Resources init finished\n");

    return 0;
}
