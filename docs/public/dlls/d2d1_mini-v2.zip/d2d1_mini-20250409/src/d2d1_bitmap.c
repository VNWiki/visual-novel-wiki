#include <stdio.h>
#include <stdlib.h>

#include "mini_d2d1.h"


//IUnknown
HRESULT WINAPI q_ID2D1Bitmap1_QueryInterface(q_ID2D1Bitmap1 *This, REFIID riid, void **ppvObject)
{
    debug_printf("ID2D1Bitmap1_QueryInterface\n");
    if (memcmp(riid, &IID_ID2D1Bitmap, 16) == 0)
    {
        This->refcount++;
        *ppvObject = (void*)This;
        return S_OK;
    }
    return E_NOINTERFACE;
}
ULONG WINAPI q_ID2D1Bitmap1_AddRef(q_ID2D1Bitmap1 *This)
{
    This->refcount++;
    return This->refcount;
}
ULONG WINAPI q_ID2D1Bitmap1_Release(q_ID2D1Bitmap1 *This)
{
    ULONG ret = --This->refcount;
    if (ret == 0)
    {
        debug_printf("freeing ID2D1Bitmap\n");
        if (This->texture) { This->texture->lpVtbl->Release(This->texture); }
        free(This);
    }
    return ret;
}

//ID2D1Resource
void WINAPI q_ID2D1Bitmap1_GetFactory(q_ID2D1Bitmap1 *This, ID2D1Factory **factory)
{
    LOGNOP_;
}

//ID2D1Bitmap
D2D1_SIZE_F WINAPI q_ID2D1Bitmap1_GetSize(q_ID2D1Bitmap1 *This)
{
    D2D1_SIZE_F ret = {};
    LOGNOP_;
    return ret;
}
D2D1_SIZE_U WINAPI q_ID2D1Bitmap1_GetPixelSize(q_ID2D1Bitmap1 *This)
{
    D2D1_SIZE_U ret = {};
    LOGNOP_;
    return ret;
}
D2D1_PIXEL_FORMAT WINAPI q_ID2D1Bitmap1_GetPixelFormat(q_ID2D1Bitmap1 *This)
{
    D2D1_PIXEL_FORMAT ret = {};
    LOGNOP_;
    return ret;
}
void WINAPI q_ID2D1Bitmap1_GetDpi(q_ID2D1Bitmap1 *This, FLOAT *dpiX, FLOAT *dpiY)
{
    LOGNOP_;
}
HRESULT WINAPI q_ID2D1Bitmap1_CopyFromBitmap(q_ID2D1Bitmap1 *This, const D2D1_POINT_2U *destPoint, ID2D1Bitmap *bitmap, const D2D1_RECT_U *srcRect)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Bitmap1_CopyFromRenderTarget(q_ID2D1Bitmap1 *This, const D2D1_POINT_2U *destPoint, ID2D1RenderTarget *renderTarget, const D2D1_RECT_U *srcRect)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Bitmap1_CopyFromMemory(q_ID2D1Bitmap1 *This, const D2D1_RECT_U *dstRect, const void *srcData, UINT32 pitch)
{
    LOGNOP;
}

//ID2D1Bitmap1
void WINAPI q_ID2D1Bitmap1_GetColorContext(q_ID2D1Bitmap1 *This, ID2D1ColorContext **colorContext)
{
    LOGNOP_;
}
D2D1_BITMAP_OPTIONS WINAPI q_ID2D1Bitmap1_GetOptions(q_ID2D1Bitmap1 *This)
{
    D2D1_BITMAP_OPTIONS ret;
    LOGNOP_;
    return ret;

}
HRESULT WINAPI q_ID2D1Bitmap1_GetSurface(q_ID2D1Bitmap1 *This, IDXGISurface **dxgiSurface)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Bitmap1_Map(q_ID2D1Bitmap1 *This, D2D1_MAP_OPTIONS options, D2D1_MAPPED_RECT *mappedRect)
{
    LOGNOP;
}
HRESULT WINAPI q_ID2D1Bitmap1_Unmap(q_ID2D1Bitmap1 *This)
{
    LOGNOP;
}



const q_ID2D1Bitmap1_vtbl _ID2D1Bitmap1_vtbl =
{
    //IUnknown
    &q_ID2D1Bitmap1_QueryInterface,
    &q_ID2D1Bitmap1_AddRef,
    &q_ID2D1Bitmap1_Release,

    //ID2D1Resource
    &q_ID2D1Bitmap1_GetFactory,

    //ID2D1Bitmap
    &q_ID2D1Bitmap1_GetSize,
    &q_ID2D1Bitmap1_GetPixelSize,
    &q_ID2D1Bitmap1_GetPixelFormat,
    &q_ID2D1Bitmap1_GetDpi,
    &q_ID2D1Bitmap1_CopyFromBitmap,
    &q_ID2D1Bitmap1_CopyFromRenderTarget,
    &q_ID2D1Bitmap1_CopyFromMemory,

    //ID2D1Bitmap1
    &q_ID2D1Bitmap1_GetColorContext,
    &q_ID2D1Bitmap1_GetOptions,
    &q_ID2D1Bitmap1_GetSurface,
    &q_ID2D1Bitmap1_Map,
    &q_ID2D1Bitmap1_Unmap
};
