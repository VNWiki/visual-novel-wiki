#include <stdio.h>
#include <stdlib.h>

#include "mini_d2d1.h"


//IUnknown
HRESULT WINAPI q_ID2D1Device_QueryInterface(q_ID2D1Device *This, REFIID riid, void **ppvObject)
{
    LOGNOP;
}
ULONG WINAPI q_ID2D1Device_AddRef(q_ID2D1Device *This)
{
    This->refcount++;
    return This->refcount;
}
ULONG WINAPI q_ID2D1Device_Release(q_ID2D1Device *This)
{
    ULONG ret = --This->refcount;
    if (ret == 0)
    {
        debug_printf("freeing ID2D1Device\n");
        free(This);
    }
    return ret;
}

//ID2D1Resource
void WINAPI q_ID2D1Device_GetFactory(q_ID2D1Device *This, ID2D1Factory **factory)
{
    LOGNOP_;
}


HRESULT WINAPI q_ID2D1Device_CreateDeviceContext(q_ID2D1Device *This, D2D1_DEVICE_CONTEXT_OPTIONS options, q_ID2D1DeviceContext **deviceContext)
{
    q_ID2D1DeviceContext *context;

    debug_printf("CreateDeviceContext\n");

    context = (q_ID2D1DeviceContext*)malloc(sizeof(q_ID2D1DeviceContext));
    context->vtbl = &_ID2D1DeviceContext_vtbl;
    context->refcount = 1;
    context->parent = This;
    context->currentTarget = NULL;
    context->primitiveBlend = D2D1_PRIMITIVE_BLEND_SOURCE_OVER;

    *deviceContext = context;
    return S_OK;
}
HRESULT WINAPI q_ID2D1Device_CreatePrintControl(q_ID2D1Device *This, IWICImagingFactory *wicFactory, IPrintDocumentPackageTarget *documentTarget, CONST D2D1_PRINT_CONTROL_PROPERTIES *printControlProperties, ID2D1PrintControl **printControl)
{
    LOGNOP;
}
void WINAPI q_ID2D1Device_SetMaximumTextureMemory(q_ID2D1Device *This, UINT64 maximumInBytes)
{
    LOGNOP_;
}
UINT64 WINAPI q_ID2D1Device_GetMaximumTextureMemory(q_ID2D1Device *This)
{
    LOGNOP;
}
void WINAPI q_ID2D1Device_ClearResources(q_ID2D1Device *This, UINT32 millisecondsSinceUse)
{
    LOGNOP_;
}




const q_ID2D1Device_vtbl _ID2D1Device_vtbl =
{
    //IUnknown
    &q_ID2D1Device_QueryInterface,
    &q_ID2D1Device_AddRef,
    &q_ID2D1Device_Release,

    //ID2D1Resource
    &q_ID2D1Device_GetFactory,

    //ID2D1Device
    &q_ID2D1Device_CreateDeviceContext,
    &q_ID2D1Device_CreatePrintControl,
    &q_ID2D1Device_SetMaximumTextureMemory,
    &q_ID2D1Device_GetMaximumTextureMemory,
    &q_ID2D1Device_ClearResources
};
