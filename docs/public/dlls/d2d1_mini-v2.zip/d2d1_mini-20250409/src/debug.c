#include <stdio.h>
#include <windows.h>

#include "mini_d2d1.h"

#ifndef DLLQUIET

HRESULT __fastcall _debug_LOGNOP(const char *s)
{
    _debug_LOGNOP_(s); return E_NOTIMPL;
}
void __fastcall _debug_LOGNOP_(const char *s)
{
    debug_printf("NOTIMPL [%s]\n", s);
}


#endif
