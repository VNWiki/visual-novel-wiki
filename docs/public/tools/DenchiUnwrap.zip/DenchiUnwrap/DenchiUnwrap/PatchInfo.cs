﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DenchiUnwrap
{
    class PatchInfo
    {
        public string FileName { get; set; }
        public uint Offset { get; set; }
        public byte[] OrigInitPatchBytes { get; set; }
        public int Length { get; set; }
        public byte[] PatchedInitPatchBytes { get; set; }
        public int Reserved { get; set; }
    }
}
