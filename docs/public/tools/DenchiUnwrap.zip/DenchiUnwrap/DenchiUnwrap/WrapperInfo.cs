﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DenchiUnwrap
{
    class WrapperInfo : IDisposable
    {
        FileStream wrapperStream;
        BinaryReader br;
        PeLite pe;
        long overlayOffset;

        public SdWrapperFlags Flags { get; private set; }
        public string LaunchExeName { get; private set; }
        public PatchInfo[] Patches { get; private set; }

        WrapperInfo()
        {
            Patches = new PatchInfo[256];
        }

        public WrapperInfo(string path)
            : this()
        {
            wrapperStream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            br = new BinaryReader(wrapperStream);
            pe = new PeLite(wrapperStream);

            overlayOffset = pe.GetPeLength();
            wrapperStream.Seek(overlayOffset, SeekOrigin.Begin);
            if (wrapperStream.Position == wrapperStream.Length) throw new ArgumentException("No overlay found, probably not SoftDenchi Wrapper protected executable.");
            string magic = new string(br.ReadChars(4));

            switch (magic)
            {
                case "SdW7":
                case "SdW6":
                case "SdW5":
                case "SdW4":
                    load_v4_v5_v6_v7();
                    break;
                case "SdW3":
                case "SdW2":
                    load_v2_v3();
                    break;
                case "SdW\0":
                    load_v1();
                    break;
                default:
                    throw new NotSupportedException("This SoftDenchi Wrapper version is not supported, or the executable is not SoftDenchi Wrapper protected.");
            }
        }

        public void UnwrapAll()
        {
            string basePath = Path.GetDirectoryName(wrapperStream.Name);
            DateTime wrapperModTime = File.GetLastWriteTime(wrapperStream.Name);

            if ((Flags & SdWrapperFlags.UnpatchOnDisk) == SdWrapperFlags.UnpatchOnDisk)
            {
                Console.WriteLine("Unwrapping payload...");
                string targetName = Path.Combine(basePath, Path.GetFileNameWithoutExtension(wrapperStream.Name) + "_unwrapped" + Path.GetExtension(wrapperStream.Name));
                using (FileStream fs = File.Create(targetName))
                {
                    BinaryWriter bw = new BinaryWriter(fs);

                    wrapperStream.Seek(overlayOffset + 0x10000, SeekOrigin.Begin);
                    wrapperStream.CopyTo(fs);

                    foreach (PatchInfo patch in Patches)
                    {
                        if (patch.Offset == 0 && patch.FileName == string.Empty) break;
                        fs.Seek(patch.Offset, SeekOrigin.Begin);
                        byte[] toDecrypt = new BinaryReader(fs).ReadBytes(patch.Length == 0 ? 4 : patch.Length);
                        decryptPatch(toDecrypt, patch, false);
                        fs.Seek(patch.Offset, SeekOrigin.Begin);
                        bw.Write(toDecrypt);
                    }

                    fs.Flush();
                }
                File.SetLastWriteTime(targetName, wrapperModTime);
            }
            else
            {
                foreach (PatchInfo patch in Patches)
                {
                    if (patch.FileName == string.Empty)
                    {
                        if (patch.Offset == 0) break;
                        DateTime existModtime = default(DateTime);

                        string targetName;
                        if ((Flags & (SdWrapperFlags.UseExeOnDisk | SdWrapperFlags.UseCustomTempExeName)) != 0)
                        {
                            Console.WriteLine("Unwrapping {0}...", LaunchExeName);
                            targetName = Path.Combine(basePath, LaunchExeName);
                            existModtime = File.GetLastWriteTime(targetName);
                        }
                        else
                        {
                            Console.WriteLine("Unwrapping payload...");
                            targetName = Path.Combine(basePath, Path.GetFileNameWithoutExtension(wrapperStream.Name) + "_unwrapped" + Path.GetExtension(wrapperStream.Name));
                        }

                        using (FileStream fs = File.Open(targetName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                        {
                            if ((Flags & SdWrapperFlags.UseExeOnDisk) == 0)
                            {
                                wrapperStream.Seek(overlayOffset + 0x10000, SeekOrigin.Begin);
                                wrapperStream.CopyTo(fs);
                                fs.Seek(0, SeekOrigin.Begin);
                            }

                            PeLite oPe = new PeLite(fs);
                            uint patchOffset = oPe.ConvertRvaToOffset(patch.Offset);
                            fs.Seek(patchOffset, SeekOrigin.Begin);
                            byte[] toDecrypt = new BinaryReader(fs).ReadBytes(patch.Length == 0 ? 4 : patch.Length);
                            decryptPatch(toDecrypt, patch, false);
                            fs.Seek(patchOffset, SeekOrigin.Begin);
                            new BinaryWriter(fs).Write(toDecrypt);
                            fs.Flush();
                        }

                        if ((Flags & SdWrapperFlags.UseExeOnDisk) == 0)
                        {
                            File.SetLastWriteTime(targetName, wrapperModTime);
                        }
                        else
                        {
                            File.SetLastWriteTime(targetName, existModtime);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Unwrapping {0}...", patch.FileName);
                        string targetPath = Path.Combine(basePath, patch.FileName);
                        DateTime lastModTime = File.GetLastWriteTime(targetPath);
                        using (FileStream fs = File.Open(targetPath, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                        {
                            fs.Seek(patch.Offset, SeekOrigin.Begin);
                            byte[] toDecrypt = new BinaryReader(fs).ReadBytes(patch.Length == 0 ? 4 : patch.Length);
                            decryptPatch(toDecrypt, patch, false);
                            fs.Seek(patch.Offset, SeekOrigin.Begin);
                            new BinaryWriter(fs).Write(toDecrypt);
                            fs.Flush();
                        }
                        File.SetLastWriteTime(targetPath, lastModTime);
                    }
                }
            }
        }

        bool decryptPatch(byte[] data, PatchInfo patch, bool oldOrder)
        {
            uint offset;
            int length;
            if (oldOrder)
            {
                offset = (uint)patch.Length;
                length = (int)patch.Offset;
            }
            else
            {
                offset = patch.Offset;
                length = patch.Length;
            }

            if (BitConverter.ToUInt32(data, 0) == BitConverter.ToUInt32(patch.PatchedInitPatchBytes, 0))
            {
                Buffer.BlockCopy(patch.OrigInitPatchBytes, 0, data, 0, patch.OrigInitPatchBytes.Length);
                if (length > 4)
                {
                    decryptData(data, 4, length - 4, patch.Offset);
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        void load_v4_v5_v6_v7()
        {
            wrapperStream.Seek(-4, SeekOrigin.Current);
            byte[] config = br.ReadBytes(0xa1b4);
            decryptData(config, 0x10, 0x9540, BitConverter.ToUInt32(config, 8));
            Flags = (SdWrapperFlags)BitConverter.ToInt32(config, 0x4c);
            LaunchExeName = Encoding.Default.GetString(config, 0x9450, 0x100);
            LaunchExeName = LaunchExeName.Substring(0, LaunchExeName.IndexOf('\0'));
            int pos = 0x50;
            for (int i = 0; i < 256; ++i)
            {
                PatchInfo pi = new PatchInfo();
                pi.FileName = Encoding.Default.GetString(config, pos, 0x80);
                pi.FileName = pi.FileName.Substring(0, pi.FileName.IndexOf('\0'));
                pi.Offset = BitConverter.ToUInt32(config, pos + 0x80);
                pi.OrigInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 0x84, pi.OrigInitPatchBytes, 0, 4);
                pi.Length = BitConverter.ToInt32(config, pos + 0x88);
                pi.PatchedInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 0x8c, pi.PatchedInitPatchBytes, 0, 4);
                pi.Reserved = BitConverter.ToInt32(config, pos + 0x90);
                Patches[i] = pi;
                pos += 0x94;
            }
        }

        void load_v2_v3()
        {
            wrapperStream.Seek(-4, SeekOrigin.Current);
            byte[] config = br.ReadBytes(0x1290);
            decryptData(config, 0x10, 0x1280, BitConverter.ToUInt32(config, 8));
            Flags = (SdWrapperFlags)BitConverter.ToInt32(config, 0x4c);
            LaunchExeName = string.Empty;
            int pos = 0x50;
            for (int i = 0; i < 16; ++i)
            {
                PatchInfo pi = new PatchInfo();
                pi.FileName = Encoding.Default.GetString(config, pos, 0x100);
                pi.FileName = pi.FileName.Substring(0, pi.FileName.IndexOf('\0'));
                pi.Offset = BitConverter.ToUInt32(config, pos + 0x100);
                pi.OrigInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 0x104, pi.OrigInitPatchBytes, 0, 4);
                pi.Length = BitConverter.ToInt32(config, pos + 0x108);
                pi.PatchedInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 0x10c, pi.PatchedInitPatchBytes, 0, 4);
                pi.Reserved = BitConverter.ToInt32(config, pos + 0x110);
                Patches[i] = pi;
                pos += 0x114;
            }
            for (int i = 16; i < 256; ++i)
            {
                Patches[i] = new PatchInfo { FileName = string.Empty, Offset = 0 };
            }
        }

        void load_v1()
        {
            wrapperStream.Seek(-4, SeekOrigin.Current);
            byte[] config = br.ReadBytes(0x150);
            decryptData(config, 0x10, 0x140, BitConverter.ToUInt32(config, 8));
            Flags = (SdWrapperFlags)BitConverter.ToInt32(config, 0x4c);
            LaunchExeName = string.Empty;
            int pos = 0x50;
            for (int i = 0; i < 16; ++i)
            {
                PatchInfo pi = new PatchInfo();
                pi.FileName = string.Empty;
                pi.Offset = BitConverter.ToUInt32(config, pos);
                pi.OrigInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 4, pi.OrigInitPatchBytes, 0, 4);
                pi.Length = 0;
                pi.PatchedInitPatchBytes = new byte[4];
                Buffer.BlockCopy(config, pos + 8, pi.PatchedInitPatchBytes, 0, 4);
                pi.Reserved = 0;
                Patches[i] = pi;
                pos += 16;
            }
            for (int i = 16; i < 256; ++i)
            {
                Patches[i] = new PatchInfo { FileName = string.Empty, Offset = 0 };
            }
        }

        void decryptData(byte[] data, int offset, int length, uint key)
        {
            Rnd521 rnd = new Rnd521(key);
            for (int i = offset; i < offset + length; ++i)
            {
                data[i] ^= (byte)rnd.Next();
            }
        }

        public void Dispose()
        {
            wrapperStream.Close();
        }
    }

    // Truncated flags, only essentials here
    [Flags]
    enum SdWrapperFlags
    {
        UseCustomTempExeName = 8,
        UseExeOnDisk = 0x40,
        UnpatchOnDisk = 0x100
    }
}
