﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DenchiUnwrap
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("SoftDenchi Unwrapper");
            Console.WriteLine("(C) 2015");
            Console.WriteLine();

            if (args.Length == 0)
            {
                Console.WriteLine("Drag and drop SoftDenchi wrapped EXE to unwrap.");
                return;
            }

            try
            {
                Console.WriteLine("Loading Denchi wrapper...");
                using (WrapperInfo wrapper = new WrapperInfo(args[0]))
                {
                    Console.WriteLine("Beginning unwrap");
                    wrapper.UnwrapAll();
                }
                Console.WriteLine("Unwrapping complete.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error unwrapping: {0}", ex.Message);
            }
        }
    }
}
