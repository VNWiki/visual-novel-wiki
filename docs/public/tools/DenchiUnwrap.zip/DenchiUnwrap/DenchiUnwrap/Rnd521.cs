﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DenchiUnwrap
{
    // Based on http://www.ysr.net.it-chiba.ac.jp/data/sim-na/rand.c
    class Rnd521
    {
        int jrnd;
        uint[] x = new uint[521];

        public Rnd521(uint seed = 0)
        {
            init_rnd(seed);
        }

        void init_rnd(uint seed)
        {
            uint u = 0;
            for (int i = 0; i <= 16; ++i)
            {
                for (int j = 0; j < 32;++j)
                {
                    seed = seed * 1566083941 + 1;
                    u = (u >> 1) | seed & ((uint)1 << 31);
                }
                x[i] = u;
            }

            x[16] = (x[16] << 23) ^ (x[0] >> 9) ^ x[15];
            for (int i = 17; i < 521; ++i)
            {
                x[i] = (x[i - 17] << 23) ^ (x[i - 16] >> 9) ^ x[i - 1];
            }

            // warm up
            rnd521();
            rnd521();
            rnd521();
            jrnd = 520;
        }

        void rnd521()
        {
            for (int i = 0; i < 32; ++i)
            {
                x[i] ^= x[i + 489];
            }
            for (int i = 32; i< 521;++i)
            {
                x[i] ^= x[i - 32];
            }
        }

        public uint Next()
        {
            if(++jrnd >= 521)
            {
                rnd521();
                jrnd = 0;
            }
            return (uint)x[jrnd];
        }
    }
}
